def choleski_decomposition(a, n, epsilon):
    return None


def compute_det(d):
    return None


def solve_system(a, b, d, epsilon):
    return None


def lu_solution(a, b):
    return None


def norm_check(a, b, x):
    return None
